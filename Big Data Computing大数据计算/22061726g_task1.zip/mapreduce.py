import csv
import pandas as pd
import sys
import os

f = open("Train_Data.csv","r")
filereader= csv.reader(f)
header = next(filereader)
n = open("train.txt",'w+')

for row in filereader:
		print(row[3],row[4],row[18],row[19],row[17],file = n)
f.close()
n.close()

n= open('train.txt','r')
input_data=n.readlines()
def mapper(input_data):
    map_result = []
    for line in input_data:
        datas = line.strip().split(' ')
        datas_float = list(map(float,datas))
        data1=datas_float[0]*datas_float[2]+datas_float[1]*datas_float[3]
        data2=datas_float[4]
        data=[data1,data2]
        map_result.append(data)
    return map_result
map_result=mapper(input_data)
print(map_result)


def reducer(mapper_result):
    for i in range(len(mapper_result)):
        cost = mapper_result[i][0]
        rate = mapper_result[i][1]
        total_cost = cost*rate
        print(total_cost)
        i = i+1

reducer(map_result)
